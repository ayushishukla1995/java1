package com.cg.iodemo;

import java.io.File;
import java.io.IOException;

public class MainClass {

	public static void main(String[] args) {
		try {
			File file=new File("D:\\Lab2EStudyMaterialPath.txt");//location+name
			if(!file.exists())
				file.createNewFile();
			System.out.println(file.canWrite());
			System.out.println(file.getName());
			System.out.println(file.canExecute());
		} catch(IOException e) {
			e.printStackTrace();
	}
	}
}