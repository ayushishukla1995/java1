package com.cg.payroll.client;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.payroll.services.PayrollServices;
import com.cg.payroll.payroll.services.PayrollservicesImpl;

public class MainClass {

	public static void main(String[] args) {
		try {
		PayrollServices payrollServices=new PayrollservicesImpl();
		int associateID=payrollServices.acceptAssociateDetails(1000,"ayushi","shukla","ayushi@gmail.com","cs","GGJJH889", 40000, 2000, 1000, 43544354, "HDFC6", "HDFR578");
	System.out.println(associateID);
	
		Associate associate=payrollServices.getAssociateDetails(associateID);
		System.out.println(associate);
		System.out.println(payrollServices.getAllAssociateDetails());
		
	} catch (AssociateDetailsNotFoundException e) {
		
		e.printStackTrace();
	}
	}
}
		