package com.cg.payroll.dao.services;

import java.util.List;

import com.cg.payroll.beans.Associate;

public interface  AssociateDao 
{
	Associate save(Associate associate);// to save asso details
	boolean update(Associate associate);// update asso details
	Associate findOne(int associateid);//to find asso id
	List <Associate> findAll();// to find all asso details
}
