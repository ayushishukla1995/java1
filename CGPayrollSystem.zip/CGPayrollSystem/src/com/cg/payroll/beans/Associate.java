package com.cg.payroll.beans;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="AssociateEntity")
public class Associate  {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int associateID;
	private int yearlyInvestment;
	private String firstName,lastName,department,pancrd,emailid;
	
@Embedded
	private	Salary salary;

@Embedded
	private Bankdetails bankdetails;
	
	
	public Associate(int associateID, int yearlyInvestment, String firstName, String lastName, String department,
			String pancrd, String emailid, Salary salary, Bankdetails bankdetails) {
		super();
		this.associateID = associateID;
		this.yearlyInvestment = yearlyInvestment;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.pancrd = pancrd;
		this.emailid = emailid;
		this.salary = salary;
		this.bankdetails = bankdetails;
	}
	

	public Associate(int yearlyInvestment, String firstName, String lastName, String department, String pancrd,
			String emailid, Salary salary, Bankdetails bankdetails) {
		super();
		this.yearlyInvestment = yearlyInvestment;
		this.firstName = firstName;
		this.lastName = lastName;
		this.department = department;
		this.pancrd = pancrd;
		this.emailid = emailid;
		this.salary = salary;
		this.bankdetails = bankdetails;
	}
	public int getAssociateID() {
		return associateID;
	}
	public void setAssociateID(int associateID) {
		this.associateID = associateID;
	}
	public int getYearlyInvestment() {
		return yearlyInvestment;
	}
	public void setYearlyInvestment(int yearlyInvestment) {
		this.yearlyInvestment = yearlyInvestment;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getPancrd() {
		return pancrd;
	}
	public void setPancrd(String pancrd) {
		this.pancrd = pancrd;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public Salary getSalary() {
		return salary;
	}
	public void setSalary(Salary salary) {
		this.salary = salary;
	}
	public Bankdetails getBankdetails() {
		return bankdetails;
	}
	public void setBankdetails(Bankdetails bankdetails) {
		this.bankdetails = bankdetails;
	}
	@Override
	public String toString() {
		return "Associate [associateID=" + associateID + ", yearlyInvestment=" + yearlyInvestment + ", firstName="
				+ firstName + ", lastName=" + lastName + ", department=" + department + ", pancrd=" + pancrd
				+ ", emailid=" + emailid + ", salary=" + salary + ", bankdetails=" + bankdetails + "]";
	}
	
}

	