package com.cg.payroll.test;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;//for assert
import java.util.ArrayList;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.easymock.EasyMock;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Bankdetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.dao.services.AssociateDao;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.payroll.services.PayrollServices;
import com.cg.payroll.payroll.services.PayrollservicesImpl;


public class PayrollServicesTestEasyMock {
	public PayrollServicesTestEasyMock() {
	}
	
	public static PayrollServices payrollservices;
	public static AssociateDao mockAssociateDao;
	
	@BeforeClass
	public static void setUpTestEnv() {
		mockAssociateDao=EasyMock.mock(AssociateDao.class);
		payrollservices=new PayrollservicesImpl(mockAssociateDao);
		
	}
	@Before
	public void setUpTestMockData() {
		Associate associate=new Associate(101,6000, "Ayushi", "shukla", "IT", "analyst", "FHA612GF", new Salary(6000, 1500, 1200), new Bankdetails(121324325, "HDFC", "hdfc26564g"));
		Associate associate1=new Associate(102,2000, "neha", "Rawat", "IT", "Data Analyst", "AF60154KL", new Salary(5000, 1500, 1200), new Bankdetails(13001212, "HDFC", "hdfc30458g"));
		Associate associate2=new Associate(1234,3000, "neelam", "Singh", "IT", "Data Analyst", "AF60154KL", new Salary(5000, 1500, 1200), new Bankdetails(13001212, "HDFC", "hdfc30458g"));
		
		ArrayList<Associate>associateList=new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		
		EasyMock.expect(mockAssociateDao.save(associate2)).andReturn (associate2);	
		
		EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate);
		EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate1);
		EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
		EasyMock.expect(mockAssociateDao.findAll()).andReturn(associateList);
		EasyMock.replay(mockAssociateDao);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssociateid() throws AssociateDetailsNotFoundException{
		payrollservices.getAssociateDetails(1234);
		 EasyMock.verify(mockAssociateDao.findOne(1234));
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForValidAssociateid() throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(102,2000, "neha", "Rawat", "IT", "Data Analyst", "AF60154KL", new Salary(5000, 1500, 1200), new Bankdetails(13001212, "HDFC", "hdfc30458g"));
		Associate actualAssociate=payrollservices.getAssociateDetails(102);
		  assertEquals(expectedAssociate, actualAssociate);
			EasyMock.verify(mockAssociateDao.findOne(102));
	    
		
	}
	@After
	public void tearDownTestMockData() {
		EasyMock.resetToDefault(mockAssociateDao);
		
	}
	@AfterClass
	public static void tearDownTestEnv() {
		mockAssociateDao=null;
		payrollservices=null;
		
}
}
