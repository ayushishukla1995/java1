package com.cg.payroll.payroll.services;

public class PayrolLServicesDownException extends Exception {

	public PayrolLServicesDownException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PayrolLServicesDownException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public PayrolLServicesDownException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public PayrolLServicesDownException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public PayrolLServicesDownException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
