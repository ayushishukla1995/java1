package com.cg.payroll.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public interface PayrollServices 
{
	public int acceptAssociateDetails(int yearlyInvestment, String firstName, String lastName, String emailid,
			String department, String pancrd,int basicSalary,int epf, int companypf, int accountNumber, String bankName, String ifscCode) ;
	  int  calculateNetSalary(int associateid)throws AssociateDetailsNotFoundException;
		
	Associate getAssociateDetails(int associateid)throws AssociateDetailsNotFoundException;
			List<Associate> getAllAssociateDetails();// to print all associate details
		
	}
 
	
	
		
	

