package com.cg.payroll.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Bankdetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.dao.services.AssociateDao;
import com.cg.payroll.dao.services.AssociateDaoImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public  class PayrollservicesImpl implements PayrollServices{
	
private AssociateDao associateDao;

public PayrollservicesImpl() {
	associateDao=new AssociateDaoImpl();// to link 
}

public PayrollservicesImpl(AssociateDao associateDao) {
	super();
	this.associateDao=associateDao;
}

/*public int acceptAssociateDetails(int yearlyInvestment, String firstName, String lastName, String emailid,
		String department, String pancrd,int basicSalary,int epf, int companypf, int accountNumber, String bankName, String ifscCode) {


	Associate associate=new Associate(yearlyInvestment, firstName, lastName, department, pancrd, emailid, new Salary(basicSalary, epf, companypf),new Bankdetails(accountNumber, bankName, ifscCode));
	associate= associateDao.save(associate) ;
	return associate.getAssociateID();*/


@Override
public Associate getAssociateDetails(int associateid) throws AssociateDetailsNotFoundException {
Associate associate=associateDao.findOne(associateid);
	return associate ;
}

	public int calculateNetSalary(int associateid) throws AssociateDetailsNotFoundException {
		Associate associate=this.getAssociateDetails(associateid);
		float mothlytax,hra,conveyanceAllowance,otherAllowance,personalAllowance,grossSalary,netSalary = 0,annualTax=0,taxableAmount,annualSalary;
		hra=(associate.getSalary().getBasicSalary()*40)/100;
		conveyanceAllowance=(associate.getSalary().getBasicSalary()*30)/100;
		otherAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		personalAllowance=(associate.getSalary().getBasicSalary()*20)/100;
		grossSalary=associate.getSalary().getBasicSalary()+hra+conveyanceAllowance+otherAllowance+personalAllowance;
		annualSalary=grossSalary*12;
		taxableAmount=annualSalary-associate.getYearlyInvestment()-associate.getSalary().getEpf()*12-associate.getSalary().getCompanypf()*12;
		if(taxableAmount<250000)
			annualTax=0;
		if(taxableAmount>250001&&taxableAmount<=500000)
			annualTax=annualTax+((taxableAmount-250000)*10)/100;
		if(taxableAmount>500000&&taxableAmount<=1000000)
		annualTax=250000+((taxableAmount-250000)*20)/100;
		if(taxableAmount>500000 &&taxableAmount<=1000000)
			annualTax=25000+((taxableAmount-250000)*30)/100;
		//monthlyTax=annualTax/12;//
		//netSalary=grossSalary-associate.getSalary().getEpf()-associate.getSalary().getCompanypf()-monthlyTax;//
		return(int)netSalary;
	}
@Override
public List<Associate> getAllAssociateDetails() {
	return associateDao.findAll();
	
}

@Override
public int acceptAssociateDetails(int yearlyInvestment, String firstName, String lastName, String emailid,
		String department, String pancrd, int basicSalary, int epf, int companypf, int accountNumber, String bankName,
		String ifscCode) {
	Associate associate=new Associate(yearlyInvestment, firstName, lastName, department, pancrd, emailid, new Salary(basicSalary, epf, companypf),new Bankdetails(accountNumber, bankName, ifscCode));
	associate= associateDao.save(associate) ;
	return associate.getAssociateID();
}

}
