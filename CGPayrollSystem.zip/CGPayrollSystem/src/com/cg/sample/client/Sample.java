package com.cg.sample.client;

public interface Sample {

}
