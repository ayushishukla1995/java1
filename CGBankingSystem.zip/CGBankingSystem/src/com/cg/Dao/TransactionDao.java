package com.cg.Dao;

import java.util.List;

import com.cg.bean.Transaction;

public interface TransactionDao {
	Transaction save(Transaction transaction);
	boolean update(Transaction transaction);
	Transaction findOne(int transactionId);
	List<Transaction> findAll();
}

