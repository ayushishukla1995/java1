package com.cg.Dao;

import java.util.List;

import com.cg.bean.Account;

public interface AccountDao {
	Account save(Account account);
	boolean update(Account account);
	Account findOne(int accountNo);
	List<Account> findAll();
	
}

