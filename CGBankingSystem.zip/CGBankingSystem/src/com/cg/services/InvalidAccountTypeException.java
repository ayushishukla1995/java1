package com.cg.services;

public class InvalidAccountTypeException extends Exception {

}
