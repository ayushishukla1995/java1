package com.cg.services;

public class InvalidPinNumberException extends Exception {

}
