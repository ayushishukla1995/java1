package com.cg.services;

public class BankingServicesDownException extends Exception {

}
