package com.cg.services;

public class InsufficientAmountException extends Exception {

}
