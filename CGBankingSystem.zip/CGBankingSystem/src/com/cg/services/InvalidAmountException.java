package com.cg.services;

public class InvalidAmountException extends Exception {

}
