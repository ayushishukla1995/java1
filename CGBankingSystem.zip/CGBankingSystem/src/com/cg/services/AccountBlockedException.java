package com.cg.services;

public class AccountBlockedException extends Exception {

}
