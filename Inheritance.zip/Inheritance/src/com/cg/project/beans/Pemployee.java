package com.cg.project.beans;

import javax.persistence.Entity;

@Entity(name="PEmployee1")
public class Pemployee extends Employee {
public Pemployee(int empId, String firstName, String lastName, String email) {
		super(empId, firstName, lastName, email);
		// TODO Auto-generated constructor stub
	}

private int hra,ta,da;

@Override
public int getEmpId() {
	// TODO Auto-generated method stub
	return super.getEmpId();
}

@Override
public void setEmpId(int empId) {
	// TODO Auto-generated method stub
	super.setEmpId(empId);
}

@Override
public String getFirstName() {
	// TODO Auto-generated method stub
	return super.getFirstName();
}

@Override
public void setFirstName(String firstName) {
	// TODO Auto-generated method stub
	super.setFirstName(firstName);
}

@Override
public String getLastName() {
	// TODO Auto-generated method stub
	return super.getLastName();
}

@Override
public void setLastName(String lastName) {
	// TODO Auto-generated method stub
	super.setLastName(lastName);
}

@Override
public String getEmail() {
	// TODO Auto-generated method stub
	return super.getEmail();
}

@Override
public void setEmail(String email) {
	// TODO Auto-generated method stub
	super.setEmail(email);
}

@Override
protected Object clone() throws CloneNotSupportedException {
	// TODO Auto-generated method stub
	return super.clone();
}

@Override
public boolean equals(Object arg0) {
	// TODO Auto-generated method stub
	return super.equals(arg0);
}

@Override
protected void finalize() throws Throwable {
	// TODO Auto-generated method stub
	super.finalize();
}

@Override
public int hashCode() {
	// TODO Auto-generated method stub
	return super.hashCode();
}

@Override
public String toString() {
	// TODO Auto-generated method stub
	return super.toString();
}

public int getHra() {
	return hra;
}

public void setHra(int hra) {
	this.hra = hra;
}

public int getTa() {
	return ta;
}

public void setTa(int ta) {
	this.ta = ta;
}

public int getDa() {
	return da;
}

public void setDa(int da) {
	this.da = da;
}

}
