package com.cg.leavemanagementsystem.client;

public class mainClass {

}
