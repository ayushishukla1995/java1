package com.cg.leavemanagementsystem.beans;
public class studentInfo {
private String firstName,lastName;

public studentInfo(String firstName, String lastName) {
	super();
	this.firstName = firstName;
	this.lastName = lastName;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastName() {
	return lastName;
}

public void setLastName(String lastName) {
	this.lastName = lastName;
}

}
