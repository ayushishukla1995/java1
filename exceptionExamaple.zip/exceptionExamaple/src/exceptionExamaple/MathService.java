package exceptionExamaple;

public class MathService {

}
