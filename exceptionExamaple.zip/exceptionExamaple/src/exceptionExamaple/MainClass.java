package exceptionExamaple;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {


try {
	Scanner ref=new Scanner(System.in);
	System.out.println("Enter firstNumber:-");
	int num1=ref.nextInt();
	
	System.out.println("Enter secondNumber:-");
	int num2=ref.nextInt();
	
	System.out.println("Ans=" +num1/num2);
} catch(InputMismatchException e)
{
	System.err.println("Enter Only number");
}catch(ArithmeticException e) {
	System.err.println("Enter Second number other than zero");
	
	
}

	}
	

	
	}
