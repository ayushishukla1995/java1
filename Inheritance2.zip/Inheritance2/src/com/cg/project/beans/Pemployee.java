package com.cg.project.beans;

import javax.persistence.Entity;

@Entity(name="PEmployee2")
public class Pemployee extends Employee {
public Pemployee(int empId, String firstName, String lastName, String email) {
		super(empId, firstName, lastName, email);
		
	}

private int hra,ta,da;

@Override
public int getEmpId() {
	
	return super.getEmpId();
}

@Override
public void setEmpId(int empId) {
	
	super.setEmpId(empId);
}

@Override
public String getFirstName() {
	
	return super.getFirstName();
}

@Override
public void setFirstName(String firstName) {
	
	super.setFirstName(firstName);
}

@Override
public String getLastName() {
	
	return super.getLastName();
}

@Override
public void setLastName(String lastName) {
	
	super.setLastName(lastName);
}

@Override
public String getEmail() {
	
	return super.getEmail();
}

@Override
public void setEmail(String email) {
	
	super.setEmail(email);
}

@Override
protected Object clone() throws CloneNotSupportedException {
	
	return super.clone();
}

@Override
public boolean equals(Object arg0) {
	
	return super.equals(arg0);
}

@Override
protected void finalize() throws Throwable {
	
	super.finalize();
}

@Override
public int hashCode() {
	
	return super.hashCode();
}

@Override
public String toString() {
	
	return super.toString();
}

public int getHra() {
	return hra;
}

public void setHra(int hra) {
	this.hra = hra;
}

public int getTa() {
	return ta;
}

public void setTa(int ta) {
	this.ta = ta;
}

public int getDa() {
	return da;
}

public void setDa(int da) {
	this.da = da;
}

}
