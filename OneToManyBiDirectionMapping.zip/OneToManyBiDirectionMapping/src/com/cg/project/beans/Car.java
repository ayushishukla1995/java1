package com.cg.project.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity(name="Car1")
public class Car {
@Id
@GeneratedValue(strategy=GenerationType.SEQUENCE)
private int carCode;
private String carType;
private int price;
@OneToOne//(mappedBy="car")//
private Customer customer;

public Car() {}

public Car(int carCode, String carType, int price, Customer customer) {
	super();
	this.carCode = carCode;
	this.carType = carType;
	this.price = price;
	this.customer = customer;
}

public int getCarCode() {
	return carCode;
}

public void setCarCode(int carCode) {
	this.carCode = carCode;
}

public String getCarType() {
	return carType;
}

public void setCarType(String carType) {
	this.carType = carType;
}

public int getPrice() {
	return price;
}

public void setPrice(int price) {
	this.price = price;
}

public Customer getCustomer() {
	return customer;
}

public void setCustomer(Customer customer) {
	this.customer = customer;
}

@Override
public String toString() {
	return "Car [carCode=" + carCode + ", carType=" + carType + ", price=" + price + ", customer=" + customer + "]";
}

}



